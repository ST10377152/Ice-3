/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package oddsquaressum;

/**
 *
 * @author lab_services_student
 */
import java.util.Iterator;
public class OddSquaresSum implements Iterable<Integer> {
    public Iterator<Integer> iterator() {
        return new Iterator<Integer>() {
            private int current = 1;
            private int sum = 0;

            public boolean hasNext() {
                return true; 
            }

            public Integer next() {
                int square = current * current;
                sum += square;
                current += 2; 
                return sum;
            }

            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }
    public static void main(String[] args) {
        // TODO code application logic here
    OddSquaresSum generator = new OddSquaresSum();
        Iterator<Integer> iterator = generator.iterator();
        for (int i = 0; i < 5; i++) { 
            System.out.println(iterator.next());
        }
    }
}
